﻿USE [SampleDB]
GO

/****** Object:  Table [dbo].[Member]    Script Date: 09-Oct-21 11:42:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Member](
	[id] [int] NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Contact] [nvarchar](50) NULL,
	[Address] [nvarchar](50) NULL,
 CONSTRAINT [PK_Member] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO



/****** Object:  StoredProcedure [dbo].[sp_AddMember]    Script Date: 09-Oct-21 11:42:27 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 ALTER PROCEDURE [dbo].[sp_AddMember]
 @id int, @Name Nvarchar(50) , @Contact nvarchar(50), @Address Nvarchar(50), @retVal int output
 AS
 BEGIN
     SET NOCOUNT ON;
     Insert into member([id],[Name],Contact,[Address]) VALUES(@id,@Name,@Contact,@Address)
     if @@ROWCOUNT > 0
     BEGIN
     SET @retVal = 200
     END
     ELSE
     BEGIN
     SET @retVal = 500
     END
 END


/****** Object:  StoredProcedure [dbo].[sp_DeleteMember]    Script Date: 09-Oct-21 11:42:41 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 ALTER PROCEDURE [dbo].[sp_DeleteMember]
 @id int, @retVal int output
 AS
 BEGIN
     SET NOCOUNT ON;
     Delete member where Id = @id
 if @@ROWCOUNT > 0 BEGIN SET @retVal = 200 END ELSE BEGIN SET @retVal = 500 END
 END;


/****** Object:  StoredProcedure [dbo].[sp_GetMember]    Script Date: 09-Oct-21 11:42:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 ALTER PROCEDURE [dbo].[sp_GetMember]
 AS
 BEGIN
     SET NOCOUNT ON;
     Select * from  members 

 END;


/****** Object:  StoredProcedure [dbo].[sp_UpdateMember]    Script Date: 09-Oct-21 11:43:11 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[sp_UpdateMember]
 @id int, @Name Nvarchar(50) , @Contact nvarchar(50), @Address Nvarchar(50), @retVal int output
 AS
 BEGIN
     SET NOCOUNT ON;
     UPDATE member SET [Name] = @Name, Contact=@Contact, [Address] = @Address where Id = @id
 if @@ROWCOUNT > 0 BEGIN SET @retVal = 200 END ELSE BEGIN SET @retVal = 500 END
 END