﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebAPIDapper.Models 
{
    public partial class Employee
    {
        public string Name { get; set; }
        public int? Salary { get; set; }
    }
}
