﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebAPIDapper.Models 
{
    public partial class TbSoldProduct
    {
        public long Sid { get; set; }
        public long ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal UnitPrice { get; set; }
        public int SoldQuantity { get; set; }
        public DateTime Sdate { get; set; }
    }
}
